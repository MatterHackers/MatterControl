
Hot End Controls
================

From the hotend control, you can:

* Select Material
* Set Temperature
* Move Print Head
* Load and Unload Filament

Hotend and Extruder Controls

![Hotend Controls](https://lh3.googleusercontent.com/Xk53KLiAr-HkSx-CFPidXLhE5G09zrY1FSNXWAccFtCM4fb5gXK3pTKx_dFQ1jEB-XUx1Xt1F_t2_ykEsa4N35x4yw)
