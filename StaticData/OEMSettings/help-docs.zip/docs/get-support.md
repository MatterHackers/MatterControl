
# Issue Reporting

If you find a bug or a problem with MatterControl, or you wish to make a suggestion to improve the product, please file an issue on our [GitHub](https://github.com/MatterHackers/MatterControl) page.

# Forum

Visit the [MatterHackers forum](https://www.matterhackers.com/community) for lots of great information about 3D printing and MatterControl:

# Articles
Browse through the MatterControl [Information Articles](https://www.matterhackers.com/topic/mattercontrol):

# Support

If you don't find what you need in the articles or forums, have look at our [support page]()

Thanks for your support.