![](https://lh3.googleusercontent.com/XLlyBUeloa3Q1FQF8-fCD0zx036yFCLsvyUKrE9zaV-p1k4Jt4m5QK3W59c8CnwPurZ_RW2xBazi9E3AmMmhkuL_OA)
 - **Name:** Type whatever text you want to show
 - **Point Size:** Set the size of the font. This is acurate when printed to the same size as a 2D printer.
 - **Height:** Set the height you want to have the text reach up to
 - **Font:** Select the font you would like to use
