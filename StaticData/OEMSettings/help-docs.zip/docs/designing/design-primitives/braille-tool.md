
The Braille DesignApp allows for the generation of 3D-printable braille labels for the visually impaired. It is also an excellent way to explore how braille works. The Braille DesignApp supports Grade 1 and 2 English Braille.

You can find it in the DesignApps folder

![DesignApps](https://lh3.googleusercontent.com/vehxWvAGA601jOgoaITkKmzOxBvUALp9uScSe7wKOiY-UQns_gjR0gW7Rx-eaxeNw2z_jjgVSOVDLoB8ncV6D8Wjew)

The App allows you to make tiles or lines of Braille text.

![Braile Apps](https://lh3.googleusercontent.com/rKAnThI4JgSA05JQJAlyC-zepHO4eIEhwdR4Qurk8i8olRFbaugw9vfISGwk0fYAToXJ7GSLTvhyPWwwqomeCZFLDA)
