MatterControl includes many tools to help you create parts, it also has intuitive controls build right into the 3D view to help you edit parts directly.

- Moveing Parts Around
  - You can drag ports around with the mouse and move them up and down with the arrow at the top of a part
- Rotate Controls  
  ![](https://www.matterhackers.com/r/1oH3i1)
 - Scale Controls  
  ![](https://www.matterhackers.com/r/yNqiNT)
