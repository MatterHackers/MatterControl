Click on any of the scale corner controls to scale your part on the bed.

# Scaling Objects in the 3D view
![](https://www.matterhackers.com/r/yNqiNT)

