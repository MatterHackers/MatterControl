Click on any of the rotate corner controls to rotate on the plane of that control. Moving the mouse over one of the arrow indicators locks the rotation to a 45&deg; angle.

- Rotating Objects in the 3D view  
![Rotate Controls](https://www.matterhackers.com/r/1oH3i1)
