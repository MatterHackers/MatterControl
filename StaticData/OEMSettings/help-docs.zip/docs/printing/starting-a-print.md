From the print control, you can:

* Set Layer Height
* Set Fill Density
* Turn on and off Support
* Start Your Print

# Starting a Print
![](https://www.matterhackers.com/r/hzPnqV)
