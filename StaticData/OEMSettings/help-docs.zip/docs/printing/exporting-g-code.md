After [Selecting a Printer](selecting-a-printer.md) you can easily export G-Code to be printed from an SD card or saved for printing at a later time.

- Open the 'Bed' menu and select 'Export'
- Select 'Machine File (G-Code)' and click 'Export  
![](https://www.matterhackers.com/r/ckrJa9)
- Save your G-Code to a known location (or directly to your SD card)  
![](https://www.matterhackers.com/r/Eq87aq)
## Success!