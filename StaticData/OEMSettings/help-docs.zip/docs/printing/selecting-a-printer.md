If you have multiple printers that you are controlling with MatterControl it is very easy to switch between them.

1. Navigate to the 'Start' Page  
  ![](https://lh3.googleusercontent.com/uXcO0mZ92L4D7sCpXbbWAc6OOTAVfjc-Rr7Y0Tz_DKVZlMKkEmIffBmbeiOVQqWERJyFCfRzjd6Jy_WGoW2RWHNa_Q)
1. From the 'Printers...' list select the printer you want to use  
  ![](https://lh3.googleusercontent.com/sGZSGPh_kEoED-_RC09Q_hwu6qWxz01KkKm1XIvwB8tEQU0XGKy24xtTDYGY0UZqHYA3Fs3VVrZBbPnq6nLzooDY-Q)
1. You can now select an 'Empty Bed' (or an existing plate) to connect to your printer and start adding things to plate  
  ![](https://lh3.googleusercontent.com/jJTx0uZ1a3q7BIvKQLpV2cy5fJuqetsqPKyD7K0UItqIjPRpmiSLF5YwLv2boadPhrApwiag3TUz3RU730iusQ1YUZc)