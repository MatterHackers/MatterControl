
MatterControl makes it easy to change the filament on your printer

1. Select the extruder that you would like to change the filament for and then either 'Load' or 'Unload'.  
![Load Filament](https://www.matterhackers.com/r/HhgLb8)
1. Follow along with the wizard to complete the loading or unloading of filament  
![](https://www.matterhackers.com/r/vdCgyQ)